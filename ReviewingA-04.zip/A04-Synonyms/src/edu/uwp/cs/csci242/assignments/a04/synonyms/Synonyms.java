package edu.uwp.cs.csci242.assignments.a04.synonyms;
/**
 * Name:  Ishmeet Singh
 * Course:  CSCI-242
 * Section: 001 or 002 <-- choose your section
 * Assignment: A04-synonms
 *Professor : Timothy Knouthz
 * Project/Class Description :
 *                          This project will make you write a program which will contain concept of of
 * generics and collections in Java. To accomplish this, you will implement a program that uses semantic
 * similarity to answer questions about synonyms. In this assginment you will build an intelligent
 * program that can learn to answer questions.In order to do that, your program will approximate the
 * semantic similarity of any pair of words.The semantic similarity between two words is the measure
 * of the closeness of their meanings This project will also make you learn how Hashmap works, also you
 * will learn about how many methods there are to use Hashmaps.
 * .
 *
 * Known Bugs:  none???
 */

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.*;

public class Synonyms {
    /**
     * A handy implementation of the semantic descriptor vector is to use
     * a HashMap
     */
    private  HashMap<String, HashMap<String, Integer>> descriptor ;

    // Knautz added this constructor
    public Synonyms()
    {
        descriptor = new HashMap<>();
    }

    public Synonyms(URL [] corpus) {
        this();//Knautz added this line
        parseCorpus(corpus);
    }

    public  HashMap<String, HashMap<String, Integer>> getDescriptor() {

        return descriptor;
    }

    /**
     *
     * @param corpus
     */
    public void parseCorpus(URL [] corpus) {

        String file = "";
        for (URL net : corpus){
            System.out.println("Parsing : " + net);
            try{
                Scanner s = new Scanner(net.openStream());
                s.useDelimiter("[\\.\\?\\!]|\\Z");file = s.next();

            } catch (IOException e) {
                System.out.println("Cant read from the url : " + e);
            }
            file = file.toLowerCase();
            //Split the document into sentences
            String [] sentence = file.trim().split("[\\.\\?\\!]");
            //go through the sentence
            for (String sen : sentence){
                //slit sentence to words
                String [] words = sen.trim().split("\\s+");
                //
                for (String tempword : words){
                    tempword = tempword.replaceAll("\\W+", "").trim();
                    //descriptor is not getting the word?
                    if(!descriptor.containsKey(tempword)){
                        descriptor.put(tempword, new HashMap<String , Integer>());
                    }
                    //we have to retrive the descriptor for the existing word that is avaliable now.
                    HashMap<String , Integer > innerMap = descriptor.get(tempword);


                        // Check the other word in the sentence.
                        for(String otherWords : words) {
                            otherWords = otherWords.replaceAll("\\W+", " ").trim();

                            //Increment the descriptor
                            if (!tempword.equals(otherWords) && !otherWords.equals("")) {
                                int temp = innerMap.getOrDefault(otherWords, 0);
                                innerMap.put(otherWords, temp++);

                            }
                        }
                    }

            }
        }


    }


    private double sum (Collection<Integer> vec){
        double doubleSum = 0.0;
        for (int count : vec){
            doubleSum += count * count;
        }
        return Math.sqrt(doubleSum);
    }

    /**
     *
     * @param wordOne
     * @param wordTwo
     * @return
     */

    public double cosineSimilarity ( String wordOne , String wordTwo){
        double vecDot = 0.0;
        HashMap<String , Integer > a = descriptor.get(wordOne);
        HashMap<String, Integer> b = descriptor.get(wordTwo);


        if (a != null && b != null){
            double keyA = sum(a.values());
            double keyB = sum(b.values());

            for (Map.Entry<String , Integer> aOne : a.entrySet()){

                int var = b.getOrDefault(aOne.getKey(), 0);
                vecDot += (aOne.getValue() * var);
            }
            return  vecDot / (keyA * keyB);
        }
        else {
            return -1;
        }

    }

        /**
         * @param args
         */
        public static void main(String[] args){

            Scanner scan = new Scanner (System.in);
            try {
                URL [] corpus = {
                        // Pride and Prejudice, by Jane Austen
                        new  URL ( "https://www.gutenberg.org/files/1342/1342-0.txt" ),
                        // The Adventures of Sherlock Holmes, by A. Conan Doyle
                        new URL ( "http://www.gutenberg.org/files/1661/1661-0.txt" ),
                        // A Tale of Two Cities, by Charles Dickens
                        new URL ( "https://www.gutenberg.org/files/98/98-0.txt" ),
                        // Alice's Adventures In Wonderland, by Lewis Carroll
                        new URL ( "https://www.gutenberg.org/files/11/11-0.txt" ),
                        // Moby Dick; or The Whale, by Herman Melville
                        new URL ( "https://www.gutenberg.org/files/2701/2701-0.txt" ),
                        // War and Peace, by Leo Tolstoy
                        new URL ( "https://www.gutenberg.org/files/2600/2600-0.txt" ),
                        // The Importance of Being Earnest, by Oscar Wilde
                        new URL ( "http://www.gutenberg.org/cache/epub/844/pg844.txt" ),
                        // The Wisdom of Father Brown, by G.K. Chesterton
                        new URL ( "https://www.gutenberg.org/files/223/223-0.txt" ),
                };



                Synonyms sime = new Synonyms(corpus);


                System.out.println("Enter a word : ");
                String word = scan.nextLine();
                System.out.println("Enter the Choices : ");
                String wordTwo = scan.nextLine();
                String [] array;
                array = wordTwo.split(("\\s+"));
                for (String s : array) {
                    System.out.println( s + " " + sime.cosineSimilarity(word, s));

                }
                double variable = 0.0;
                double [] tempArray = new double[0];
                String obj = " ";
                for (int i = 0 ; i< array.length ; i++){
                    double tempCosine = sime.cosineSimilarity(word,array[i]);
                    if(variable < tempCosine){

                        variable = tempCosine;
                        obj = array[i];
                    }
                }
                System.out.println("Synonym of " + word + " is : " + obj);
            } catch (Exception e) {
                System.out.println("Error reading the URL !! " + e);
            }

        }

}






